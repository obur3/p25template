#include "main.h"

namespace p25 {

class Kicker {
    pros::Motor* motor;

    public:
    Kicker(pros::Motor* p_motor);

    void run();
    void coast();
    void hold();
};

}