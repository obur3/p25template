#include "main.h"

namespace p25 {

class Intake {
    pros::MotorGroup* mg;

    public:
    Intake(pros::MotorGroup* p_mg);

    void enable(uint voltage=12000);
    void reverse(uint voltage=12000);
    void coast();
};

}