#pragma once
#include "main.h"

namespace p25 {

class ShmovementDrivetrain {
    pros::MotorGroup* mg_L;
    pros::MotorGroup* mg_R;
    pros::Imu*        imu;

    double recent_velocities[50];

    public:
    ShmovementDrivetrain(pros::MotorGroup* p_mg_L, pros::MotorGroup* p_mg_R, pros::Imu* p_imu);

    void calibrateInertial(double current_heading=0.0);

    void tankDrive(int left, int right);
    void rampSpeed(int left, int right, int ms);
    void pivotLeft(int right);
    void pivotRight(int left);
    void brake();
    void coast();

    void resetOdometers();
    double getAvgDistance();
    double getHeading();
    double getTilt();
    double getVelocity();
};

}