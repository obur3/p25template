#include "main.h"

namespace p25 {

class Piston {
    pros::ADIDigitalOut* piston;

    public:
    Piston(pros::ADIDigitalOut* p_piston);

    void extend();
    void retract();
};

class Lift {
    pros::ADIDigitalOut* piston;

    public:
    Lift(pros::ADIDigitalOut* p_piston);

    void raise();
    void lower();
};

class Wings {
    pros::ADIDigitalOut* piston_left;
    pros::ADIDigitalOut* piston_right;

    public:
    Wings(pros::ADIDigitalOut* p_piston_left, pros::ADIDigitalOut* p_piston_right);

    void deployLeft();
    void deployRight();
    void deployBoth();
    void retractLeft();
    void retractRight();
    void retractBoth();
};

}