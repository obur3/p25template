#pragma once

#include "main.h" 
namespace p25 {
namespace pid {

struct PIDSettings {
    double kp;
    double ki;
    double kd;
};

class PIDController {
    double prev_error;
    double kp;
    double ki;
    double kd;
    double proportional;
    double integral;
    double derivative;

    public:
    PIDController(double p_kp=1.0, double p_ki=0.0, double p_kd=0.0);
    PIDController(PIDSettings pidsettings);

    double calculate(double error, double delta_time);
};

}
}