#include "main.h"
#include "p25/pid.hpp"

namespace p25 {

class PidDrivetrain {
    pros::MotorGroup* mg_L;
    pros::MotorGroup* mg_R;
    pros::Imu*        imu;

    std::function<void(void)> action;

    double target_heading;

    pid::PIDController rotation_heading_pid;
    pid::PIDController straight_heading_pid;
    pid::PIDController distance_pid;

    double recent_velocities[50];

    public:
    PidDrivetrain(pros::MotorGroup* p_mg_L, pros::MotorGroup* p_mg_R, pros::Imu* p_imu);

    void calibrateInertial();

    void moveUntil(std::function<bool(void)> condition);

    void tankDrive(int left, int right);

    void rotateToHeading(double target_heading, pid::PIDSettings heading_pid_settings={
        375.0,
        0.5,
        18000.0
    });
    void driveToDistance(double target_distance, double heading_correction_coefficient=0.75, pid::PIDSettings distance_pid_settings={15.0,0.1,12.0}, pid::PIDSettings heading_pid_settings={60.0, 0.0, 0.0});
    bool isSettled(double settle_sum=5.0);
};

}