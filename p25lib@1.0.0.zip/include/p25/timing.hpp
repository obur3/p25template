#pragma once
#include "main.h"

namespace p25 {

class TimingSystem {

    uint32_t start_timestamp;

    public:
    TimingSystem();
    
    void reset();

    int getElapsedMillis();

    void waitFor(int ms);
    void waitUntil(std::function<bool(void)> condition);
};

}