#pragma once
#include "main.h"

namespace p25 {

struct Auton {
    std::string               name;
    std::function<void(void)> setup_func;
    std::function<void(void)> auton_func;
};

class AutonSelector {
    std::vector<Auton> autons;
    pros::Controller*  controller;
    bool is_first_run = true;
    bool is_auton_selected = false;
    int selected_auton_index = 0;

    void selectAuton();

    public:
    AutonSelector(std::vector<Auton> p_autons, pros::Controller* p_controller);

    void opcontrol();
    void autonomous();
};

}